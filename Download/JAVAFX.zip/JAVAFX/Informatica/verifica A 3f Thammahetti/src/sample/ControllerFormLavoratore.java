package sample;


import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

//Brignoli Tommaso 3F INF 18/04/2023 versione 1.0.5


public class ControllerFormLavoratore extends ControllerFormPersona{


    public Label lbl_datinseriti;
    public TextField txt_Lavoro;
    public TextField txt_anni;
    public TextField txt_nomeUtente;
    public TextField txt_cognomeUtente;
    protected String data_nascita_utente;
    public ComboBox cmbx_lavoro_predicate;
    public String durata;
    public Label lbl_errore_anni;
    public ComboBox cmbx_Mesi_Lavoro;
    public static boolean  Lavoratore_com = false;

    public void oncliclìk_Btn_Conferma_Dati(ActionEvent actionEvent) throws IOException {
        Lavoratore_com = false;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            if (User1.getUsername().equals(Account_Name)) {

                User1.setLavoro_fatto((String) cmbx_lavoro_predicate.getValue());
                User1.setDurata_lavoro((String) cmbx_Mesi_Lavoro.getValue());

                Scene scene;
                Lavoratore_com = true;
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
                scene = new Scene(fxmlLoader.load());
                Main.mainStage.setScene(scene);
                Main.mainStage.show();


            }

        }
    }


    public void onclick_Btn_Cancella_Dati(ActionEvent actionEvent) {
        lbl_datinseriti.setText("DATI INSERITI:");
        txt_Lavoro.setText("");
        txt_anni .setText("");
    }
    public void initialize() {
        String[] elenco_sport = {"", "PROFESSORE", "MATEMATICO", "PROGRAMMATORE"};
        cmbx_lavoro_predicate.setItems(FXCollections.observableArrayList(elenco_sport));
    }
    public void onclick_cmbx_lavoro_praticate(ActionEvent actionEvent) {
        String lavoro_praticato;
        boolean esistente = false;
        ComboBox cmbx_lavoro_praticate;
        lavoro_praticato=((String) cmbx_lavoro_predicate.getValue()).toUpperCase();
        for (int i= 0;i<cmbx_lavoro_predicate.getItems().size();i++) {
            if (lavoro_praticato.compareTo((String) cmbx_lavoro_predicate.getItems().get(i))==0)
                esistente = true;
        }
        if (!esistente) {
            cmbx_lavoro_predicate.getItems().add(lavoro_praticato);
        }


    }
}
