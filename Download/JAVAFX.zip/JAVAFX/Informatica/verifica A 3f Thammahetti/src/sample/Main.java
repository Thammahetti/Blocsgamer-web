package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;
//Thammahetti Mudalige Thikshana Thejan Peiris
//3FINF
//28/04/2023
//Versione: 1.0.5

public class Main extends Application {
    protected static boolean logged = true;
    public static Stage mainStage;

    @Override
    public void start(Stage primaryStage) throws IOException {
        mainStage = primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("form_login.fxml"));
        mainStage.setTitle("Verifica 3F : Thammahetti Thejan 28/04/2023 1.0.5");

        mainStage.setScene(new Scene(root));
        mainStage.show();
}
    public static void main(String[] args) throws IOException {
        launch(args);
    }
}
