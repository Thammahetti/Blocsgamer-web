package sample;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import static sample.ControllerFormPersona.*;

public class ControllerFormTifoso extends ControllerFormPersona {

    public Label lbl_note2;
    public LocalDate dataAtt = LocalDate.now();
    public int mesi_tifo;
    public int size;
    public int mesiT;
    public Label lbl_cognomeUtente1;
    public Label lbl_cognomeUtente11;
    public Button btn_cancellaDati;
    public ImageView img_immaginetifoso;
    public Button btn_return;
    public Button btn_cambiaImmagine1;

    @FXML protected ComboBox cbx_mesi;
    @FXML protected ComboBox cbx_sport;
    @FXML protected ComboBox cbx_squadra;
    ArrayList<Integer> elenco_mesi = new ArrayList<>();
    int months;
    public static boolean Tifoso_com = false;
    public void initialize() {

        mesi_tifo = 12 * eta_minima;

        if (eta_minima == 0) {
            Period age = Period.between(data_inserita, dataAtt);
            months = age.getMonths();
            size = months;
        } else {
            size = mesi_tifo;
        }

        int i = 1;
        while (i<= size) {
            elenco_mesi.add(i);
            i++;
        }
        String[] elenco_squadre = {"","MILAN","INTER","JUVE","NAPOLI","REAL MADRID","BARCELLONA","PSG","LIVERPOOL","BAYERN MONACO","CHELSEA","ARSENAL","MANCHESTER CITY","MANCHESTER UNITED"};
        cbx_squadra.setItems(FXCollections.observableArrayList(elenco_squadre));
        String[] elenco_sport = {"","CALCIO","BASKET","GOLF"};
        cbx_sport.setItems(FXCollections.observableArrayList(elenco_sport));
        cbx_mesi.setItems(FXCollections.observableArrayList(elenco_mesi));
    }


    public void onclick_btn_confermaDati(ActionEvent actionEvent) throws IOException {
        Tifoso_com = false;
        String squadra = ((String) cbx_squadra.getValue());
        String sport = ((String) cbx_sport.getValue());
        if (cbx_squadra.getValue() == null) {
            JOptionPane.showMessageDialog(null, "NON HAI RISPOSTO A TUTTE LE DOMANDE");
        }else if(cbx_sport.getValue() == null){
            JOptionPane.showMessageDialog(null, "NON HAI RISPOSTO A TUTTE LE DOMANDE");
        }else if(cbx_mesi.getValue() == null){
            JOptionPane.showMessageDialog(null, "NON HAI RISPOSTO A TUTTE LE DOMANDE");
        }else {

            for (int i = 0; i< UserList.size() ; i++) {
                User User1 = UserList.get(i);
                if (User1.getUsername().equals(Account_Name)) {

                    User1.setSquadra_tif(squadra);
                    User1.setSport_tif(sport);

                    Scene scene;
                    Tifoso_com = true;
                    FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
                    scene = new Scene(fxmlLoader.load());
                    Main.mainStage.setScene(scene);
                    Main.mainStage.show();


                }

            }
        }
    }

    public void onclick_btn_cancellaDati(ActionEvent actionEvent) {
        String[] elenco_squadre = {"","MILAN","INTER","JUVENTUS","NAPOLI","REAL MADRID","BARCELLONA","PSG","LIVERPOOL","BAYERN MONACO","CHELSEA","ARSENAL","MANCHESTER CITY","MANCHESTER UNITED","LAKERS","BULLS","GRIZLIERS"};
        cbx_squadra.setItems(FXCollections.observableArrayList(elenco_squadre));
        cbx_squadra.setEditable(true);
        cbx_squadra.setValue("");
        cbx_sport.setValue("");
        String[] elenco_sport = {"","CALCIO","BASKET","GOLF"};
        cbx_sport.setItems(FXCollections.observableArrayList(elenco_sport));
        cbx_mesi.setValue("");

        lbl_note2.setText("NOTE: ");
    }

    public void Run_cbx_squadra(ActionEvent actionEvent) {
        String squadra_preferita;
        Boolean esistente = false;
        squadra_preferita = ((String) cbx_squadra.getValue()).toUpperCase();
        for (int i=0;i<cbx_squadra.getItems().size();i++) {
            if (squadra_preferita.compareTo((String) cbx_squadra.getItems().get(i))==0)
                esistente = true;
        }
        if (!esistente) {
            cbx_squadra.getItems().add(squadra_preferita);
        }
    }

    public void Run_cbx_sport(ActionEvent actionEvent) {
        String sport_praticato;
        Boolean esistente = false;
        sport_praticato = ((String) cbx_sport.getValue()).toUpperCase();
        for (int i=0;i<cbx_sport.getItems().size();i++) {
            if (sport_praticato.compareTo((String) cbx_sport.getItems().get(i))==0)
                esistente = true;
        }
        if (!esistente) {
            cbx_sport.getItems().add(sport_praticato);
        }

    }

    public void Run_cbx_mesi(ActionEvent actionEvent) {
        int meseTifo;
        meseTifo = ((int) cbx_mesi.getValue());
        mesiT = meseTifo;
    }

    public void onclick_btn_cambiaImmagine1(ActionEvent actionEvent) throws FileNotFoundException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleziona un'immagine");

        File file = fileChooser.showOpenDialog(null);

        if (file != null) {
            String filePath = file.getAbsolutePath();
            Image image = new Image(new FileInputStream(file));
            img_immaginetifoso.setImage(image);
            for (int i = 0; i< UserList.size() ; i++) {
                User User1 = UserList.get(i);
                if (User1.getUsername().equals(Account_Name)) {
                    User1.setImage_tifoso(filePath);
                }
            }

        }
    }

    public void onclick_btn_return(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }
}
