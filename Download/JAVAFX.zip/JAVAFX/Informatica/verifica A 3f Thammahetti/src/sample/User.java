package sample;

public class User {
    private String Username;
    private String Password;
    private String Nome;
    private String Cognome;
    private int day;
    private int month;
    private  int year;
    private String DataNascita;
    private String Image_fumatore;
    private String Image_tifoso;
    private String Image_Persona;
    //FUMATORE
    private String Strumento_Util;
    private String Marca_util;
    private int temp_fum;
    //TIFOSO
    private String Squadra_tif;
    private String Sport_tif;
    private String mesi_tif;
    //SPORT
    private String sport_prat;
    private String mesi_prat;
    //LAVORATORE
    private String lavoro_fatto;
    private String durata_lavoro;
    //IMAGE

    public String getImage_fumatore() {
        return Image_fumatore;
    }

    public void setImage_fumatore(String image_fumatore) {
        Image_fumatore = image_fumatore;
    }

    public String getImage_tifoso() {
        return Image_tifoso;
    }

    public void setImage_tifoso(String image_tifoso) {
        Image_tifoso = image_tifoso;
    }

    //LAVORATORE

    public String getLavoro_fatto() {
        return lavoro_fatto;
    }

    public void setLavoro_fatto(String lavoro_fatto) {
        this.lavoro_fatto = lavoro_fatto;
    }

    public String getDurata_lavoro() {
        return durata_lavoro;
    }

    public void setDurata_lavoro(String durata_lavoro) {
        this.durata_lavoro = durata_lavoro;
    }


    //SPORT

    public String getSport_prat() {
        return sport_prat;
    }

    public void setSport_prat(String sport_prat) {
        this.sport_prat = sport_prat;
    }

    public String getMesi_prat() {
        return mesi_prat;
    }

    public void setMesi_prat(String mesi_prat) {
        this.mesi_prat = mesi_prat;
    }

    //TIFOSO

    public String getSquadra_tif() {
        return Squadra_tif;
    }

    public void setSquadra_tif(String squadra_tif) {
        Squadra_tif = squadra_tif;
    }

    public String getSport_tif() {
        return Sport_tif;
    }

    public void setSport_tif(String sport_tif) {
        Sport_tif = sport_tif;
    }

    public String getMesi_tif() {
        return mesi_tif;
    }

    public void setMesi_tif(String mesi_tif) {
        this.mesi_tif = mesi_tif;
    }




    //FUMATORE GET E SET
    public String getStrumento_Util() {
        return Strumento_Util;
    }

    public void setStrumento_Util(String strumento_Util) {
        Strumento_Util = strumento_Util;
    }

    public String getMarca_util() {
        return Marca_util;
    }

    public void setMarca_util(String marca_util) {
        Marca_util = marca_util;
    }

    public int getTemp_fum() {
        return temp_fum;
    }

    public void setTemp_fum(int temp_fum) {
        this.temp_fum = temp_fum;
    }




    public User() {
        this.Username =  Username;
        this.Password = Password;
        this.Nome = Nome;
        this.Cognome = Cognome;
        this.day = day;
        this.month = month;
        this.year = year;
        this.Image_Persona = Image_Persona;

    }

    public String getDataNascita() {
        return DataNascita;
    }

    public void setDataNascita(String dataNascita) {
        DataNascita = dataNascita;
    }
    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getCognome() {
        return Cognome;
    }

    public void setCognome(String cognome) {
        Cognome = cognome;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getImage_Persona() {
        return Image_Persona;
    }

    public void setImage_Persona(String image_Persona) {
        Image_Persona = image_Persona;
    }



    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    public String toString() {
        return Username + " " + Password + " "+ Nome + " " + Cognome;
    }
}
