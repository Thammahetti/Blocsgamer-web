package sample;


import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Controller_Stampa extends ControllerFormPersona {
    public Label lbl_nome;
    public Label lbl_cognome;
    public Label lbl_datanascita;
    public ImageView img_1;
    public RadioButton rd_sportivo;
    public RadioButton rd_lavoratore;
    public RadioButton rd_fumatore;
    public RadioButton rd_tifoso;
    public Label lbl_att_3;
    public Label lbl_att_2;
    public Label lbl_att_1;
    public RadioButton rd_persona;
    private ToggleGroup toggleGroup;
    public void initialize() throws FileNotFoundException {
        toggleGroup = new ToggleGroup();
        rd_sportivo.setToggleGroup(toggleGroup);
        rd_lavoratore.setToggleGroup(toggleGroup);
        rd_fumatore.setToggleGroup(toggleGroup);
        rd_tifoso.setToggleGroup(toggleGroup);
        rd_persona.setToggleGroup(toggleGroup);
        int pos_int_acc = 0;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            String usersd = User1.getUsername();
            if (usersd == Account_Name) {
                pos_int_acc = i;
            }

        }
        User User2 = UserList.get(pos_int_acc);
        String img_path = User2.getImage_Persona();
        Image image = new Image(new FileInputStream(img_path));
        img_1.setImage(image);
        lbl_nome.setText("Nome: " + User2.getNome());
        lbl_cognome.setText("Cognome: " + User2.getCognome());
        lbl_datanascita.setText("Data di Nascita :" + User2.getDataNascita());

    }

    public void run_rd_sportivo(ActionEvent actionEvent) throws FileNotFoundException {
        int pos_int_acc = 0;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            String usersd = User1.getUsername();
            if (usersd == Account_Name) {
                pos_int_acc = i;
            }

        }
        User User2 = UserList.get(pos_int_acc);

            lbl_att_1.setText("Sport: " + User2.getSport_prat());
            lbl_att_2.setText("Mesi Praticati: " + User2.getMesi_prat() + " Mesi");
        lbl_att_3.setText("");
            String img_path = "verifica A 3f Thammahetti/src/sample/null_image.png";
            Image image = new Image(new FileInputStream(img_path));
            img_1.setImage(image);

    }

    public void run_rd_lavoratore(ActionEvent actionEvent) throws FileNotFoundException {
        int pos_int_acc = 0;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            String usersd = User1.getUsername();
            if (usersd == Account_Name) {
                pos_int_acc = i;
            }

        }
        User User2 = UserList.get(pos_int_acc);
        if(User2.getLavoro_fatto().equals(null) || User2.getDurata_lavoro().equals(null) ) {} else {
            lbl_att_1.setText("Lavoro: " + User2.getLavoro_fatto());
            lbl_att_2.setText("Lavoratore da : " + User2.getDurata_lavoro() + " Mesi");
            lbl_att_3.setText("");
            String img_path = "verifica A 3f Thammahetti/src/sample/null_image.png";
            Image image = new Image(new FileInputStream(img_path));
            img_1.setImage(image);
        }
    }

    public void run_rd_fumatore(ActionEvent actionEvent) throws FileNotFoundException {
        int pos_int_acc = 0;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            String usersd = User1.getUsername();
            if (usersd == Account_Name) {
                pos_int_acc = i;
            }

        }
        User User2 = UserList.get(pos_int_acc);

            lbl_att_1.setText("Strumento: " + User2.getStrumento_Util());
            lbl_att_2.setText("Tabacco : " + User2.getMarca_util());
            lbl_att_3.setText("Fumando da" + User2.getTemp_fum() + " Mesi");
            String img_path = User2.getImage_fumatore();
            Image image = new Image(new FileInputStream(img_path));
            img_1.setImage(image);

    }

    public void run_rd_tifoso(ActionEvent actionEvent) throws FileNotFoundException {
        int pos_int_acc = 0;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            String usersd = User1.getUsername();
            if (usersd == Account_Name) {
                pos_int_acc = i;
            }

        }

            User User2 = UserList.get(pos_int_acc);
        if(User2.getSquadra_tif().equals(null) || User2.getSport_tif().equals(null) ) {} else {
            lbl_att_1.setText("Tifoso della Squadra: " + User2.getSquadra_tif());
            lbl_att_2.setText("Sport della Squadra: " + User2.getSport_tif());
            lbl_att_3.setText("Tifo da: " + User2.getMesi_tif() + " Mesi");
            String img_path = User2.getImage_tifoso();
            Image image = new Image(new FileInputStream(img_path));
            img_1.setImage(image);
        }
    }

    public void onclick_btn_backl(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void run_rd_persona(ActionEvent actionEvent) throws FileNotFoundException {
        int pos_int_acc = 0;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            String usersd = User1.getUsername();
            if (usersd == Account_Name) {
                pos_int_acc = i;
            }

        }
        User User2 = UserList.get(pos_int_acc);
        String img_path = User2.getImage_Persona();
        Image image = new Image(new FileInputStream(img_path));
        img_1.setImage(image);

    }
}
