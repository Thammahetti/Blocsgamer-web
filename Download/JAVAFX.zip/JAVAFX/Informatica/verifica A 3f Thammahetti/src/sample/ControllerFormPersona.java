package sample;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.time.LocalDate;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import java.text.SimpleDateFormat;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import javax.jws.soap.SOAPBinding;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.IOException;
import java.time.Period;
//Thammahetti Mudalige Thikshana Thejan Peiris
//3FINF
//28/04/2023
//Versione: 1.0.5


public class ControllerFormPersona extends Controller {

    //public  DatePicker datepicker_data;
    public DatePicker dtpick_dataUtente;
    public Button btn_confermaDati;
    public Button btn_cambiaImmagine;
    public TextField txt_cognomeUtente;
    public Label lbl_nomeUtente1;
    public Label lbl_nomeUtente11;
    public DatePicker data_picker;
    public Button btn_reset;
    public Button btn_sportivo;
    public Button btn_back;
    public Button btn_nothing;
    public Button btn_tifoso;
    public Button btn_fumatore;
    public Button btn_lavoratore;
    public Button btn_stampa;
    protected  LocalDate data_inserita;
    protected int giorno;
    protected int mese;
    protected int anno;
    public static String data_nascita_utente;
    public TextField txt_nomeUtente;
    public Label lbl_nomeUtente;
    public Label lbl_note;
    public ImageView img_immagineProfilo;
    public LocalDate data_input;
    int d;
    int m;
    public static int y;
    public static String name;
    public static String surname;
    public static int eta_minima;
    public static int eta;
    public static String Account_Name;
    public static int eta_consentita;
    int gio = 20;
    int mes = 2;
    int ann = 2002;
    public void initialize() throws FileNotFoundException {

        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            if (User1.getUsername().equals(Account_Name)) {
                String temp_user = User1.getNome();
                if(temp_user == "" || temp_user == null) {

                }else{

                    if(ControllerFormTifoso.Tifoso_com == true || ControllerFormLavoratore.Lavoratore_com == true || ControllerFumatore.Fumatore_com == true || controllersportivo.Sportivo_com == true)  {
                        btn_confermaDati.setDisable(true);
                        btn_tifoso.setDisable(false);
                        btn_lavoratore.setDisable(false);
                        btn_fumatore.setDisable(false);
                        btn_sportivo.setDisable(false);
                        btn_nothing.setDisable(true);
                        btn_stampa.setVisible(true);
                        if(ControllerFormTifoso.Tifoso_com == true) {
                            btn_tifoso.setDisable(true);

                        }
                        if(ControllerFormLavoratore.Lavoratore_com == true) {
                            btn_lavoratore.setDisable(true);

                        }
                        if(ControllerFumatore.Fumatore_com == true) {
                            btn_fumatore.setDisable(true);

                        }
                        if(controllersportivo.Sportivo_com == true) {
                            btn_sportivo.setDisable(true);

                        }

                    }else {

                    }
                    String img_path = User1.getImage_Persona();
                    Image image = new Image(new FileInputStream(img_path));
                   img_immagineProfilo.setImage(image);
                    txt_nomeUtente.setText(User1.getNome());
                    txt_cognomeUtente.setText(User1.getCognome());
                     gio = User1.getDay();
                     mes =User1.getMonth();
                     ann =  User1.getYear();
                    LocalDate data = LocalDate.of(ann, mes, gio );
                    data_picker.setValue(data);
                    data_inserita  = data_picker.getValue();
                    giorno = data_inserita.getDayOfMonth();

                    mese = data_inserita.getMonthValue();

                    anno = data_inserita.getYear();
                    data_nascita_utente = giorno + "/" + mese + "/" + anno;
                }

            }

        }

    }
    public void onclick_btn_Login(ActionEvent actionEvent) {

    }

    public void onclick_btn_confermaDati(ActionEvent actionEvent) throws IOException {
        String nome = txt_nomeUtente.getText();
        String cognome = txt_cognomeUtente.getText();
        data_inserita  = data_picker.getValue();
        giorno = data_inserita.getDayOfMonth();

        mese = data_inserita.getMonthValue();

        anno = data_inserita.getYear();

        data_nascita_utente = giorno + "/" + mese + "/" + anno;
        boolean dati_registrati = false;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            if (User1.getUsername().equals(Account_Name)) {

                User1.setNome(nome);
                User1.setCognome(cognome);
                User1.setDataNascita(data_nascita_utente);
                User1.setDay(giorno);
                User1.setMonth(mese);
                User1.setYear(anno);
                lbl_note.setVisible(true);
                LocalDate dataATTUALE = LocalDate.now();
                eta = Period.between(data_inserita, dataATTUALE ).getYears();
                eta_minima = eta - 2;
                LocalDate birthDate = data_picker.getValue();
                LocalDate legalAgeDate = LocalDate.now().minusYears(18);


                if (birthDate.isAfter(legalAgeDate)) {

                    btn_fumatore.setDisable(true);
                    btn_lavoratore.setDisable(true);
                } else {
                    btn_lavoratore.setDisable(false);
                    btn_fumatore.setDisable(false);
                }

                if (eta>2) {
                    btn_sportivo.setDisable(false);
                    btn_tifoso.setDisable(false);
                }else{
                    btn_sportivo.setDisable(true);
                    btn_tifoso.setDisable(true);
                }
                btn_nothing.setDisable(false);

            }

        }

        LocalDate dataATTUALE = LocalDate.now();
        eta = Period.between(data_inserita, dataATTUALE ).getYears();
        eta_consentita = eta - 18;



    }

    public void onclick_btn_cambiaImmagine(ActionEvent actionEvent)throws IOException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleziona un'immagine");

        File file = fileChooser.showOpenDialog(null);

        if (file != null) {
            String filePath = file.getAbsolutePath();
            Image image = new Image(new FileInputStream(file));
            img_immagineProfilo.setImage(image);
            for (int i = 0; i< UserList.size() ; i++) {
                User User1 = UserList.get(i);
                if (User1.getUsername().equals(Account_Name)) {
                    User1.setImage_Persona(filePath);
                }
            }

        }
    }


    public void run_data_picker(ActionEvent actionEvent) {

        data_input = data_picker.getValue();

        d =data_input.getDayOfMonth();
        m = data_input.getMonthValue();
        y = data_input.getYear();
        data_nascita_utente = Integer.toString(d) + "/" + Integer.toString(m) + "/" + Integer.toString(y);
    }

    public void onclick_btn_reset(ActionEvent actionEvent) {
        txt_nomeUtente.setText("");
        txt_cognomeUtente.setText("");
        data_picker.setValue(null);
        lbl_note.setText("");


    }

    public void onclick_btn_back(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_login.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();



    }

    public void onclick_btn_sportivo(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_sportivo.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void onclick_btn_lavoratore(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Lavoratore.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void onclick_btn_fumatore(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Fumatore.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void onclick_btn_tifoso(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_tifoso.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void onclick_btn_nothng(ActionEvent actionEvent) {
    btn_stampa.setVisible(true);
    btn_confermaDati.setDisable(true);
    }

    public void onclick_btn_stampa(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_stampa.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();

    }
}
