package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.IOException;


public class Controller_Register extends Controller {
    public Button btn_admin_panel;
    public Button btn_register;

    public Button btn_login_return;
    public PasswordField txt_Password_new;
    public TextField txt_Username_new;
    public Label lbl_Status_reg;
    public static String Username_new;
    public static String Password_new;

    public void initialize(){

    }

    public void run_btn_login_return(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_login.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }


    public void run_btn_register(ActionEvent actionEvent) {
        Username_new  = txt_Username_new.getText();
        Password_new = txt_Password_new.getText();

        boolean reg = false;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            if (User1.getUsername().equals(Username_new)) {
                reg = true;
            }

        }
        if (reg == true ) {
            lbl_Status_reg.setText("User: ACCOUNT " + Username_new + " ESISTENTE");
        }else {
            User User = new User();
            User.setUsername(Username_new);
            User.setPassword(Password_new);
            User.setImage_Persona("verifica A 3f Thammahetti/src/sample/paperino.png");
            UserList.add(User);
            lbl_Status_reg.setText("User: ACCOUNT  " + Username_new + " È STATO CREATO");
        }

    }

    public void run_btn_admin_panel(ActionEvent actionEvent) {
    }
}
