package sample;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import javax.swing.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

public class ControllerFumatore extends ControllerFormPersona {


    public Button btn_stampa;
    public Label lbl_stampa;
    public ImageView img_immagineProfilo1;

    @FXML
    protected ComboBox cbx_strumento;
    @FXML
    protected ComboBox cbx_marca;
    @FXML
    protected ComboBox cbx_tempofumi;

    public static Boolean Fumatore_com = false;

    public void initialize() {


        //LocalDate eta_anno = LocalDate.now().minusYears(anno);
        //LocalDate maggiorenne = eta_anno.minusYears(18);
        //int maggiorenne_anni = eta - 18;
        LocalDate dataATTUALE = LocalDate.now();

        eta_consentita = eta - 18;
        ArrayList<Integer> elenco_anni = new ArrayList<>();

        for (int i = 1; i<=eta_consentita; i++){
            elenco_anni.add(i);
            
        }

        String[] elenco_strumenti = {"", "SIGARETTA", "SIGARO", "SIGARETTA ELETTRONICA"};
        cbx_strumento.setItems(FXCollections.observableArrayList(elenco_strumenti));
        String[] elenco_marca = {"", "BENSTON", "COHIBA", "WINSTON"};
        cbx_marca.setItems(FXCollections.observableArrayList(elenco_marca));
        cbx_tempofumi.setItems(FXCollections.observableArrayList(elenco_anni));

    }

    public void run_btn_stampa(ActionEvent actionEvent) throws IOException {
        Fumatore_com = false;
        if (cbx_strumento.getValue() == null) {
            JOptionPane.showMessageDialog(null, "NON HAI RISPOSTO A TUTTE LE DOMANDE");
        }else if(cbx_marca.getValue() == null){
            JOptionPane.showMessageDialog(null, "NON HAI RISPOSTO A TUTTE LE DOMANDE");
        }else if(cbx_tempofumi.getValue() == null){
            JOptionPane.showMessageDialog(null, "NON HAI RISPOSTO A TUTTE LE DOMANDE");
        }else {
            for (int i = 0; i< UserList.size() ; i++) {
                User User1 = UserList.get(i);
                if (User1.getUsername().equals(Account_Name)) {

                    User1.setStrumento_Util((String) cbx_strumento.getValue());
                    User1.setMarca_util((String) cbx_marca.getValue());
                    User1.setTemp_fum((Integer) cbx_tempofumi.getValue());
                    Scene scene;
                    Fumatore_com = true;
                    FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
                    scene = new Scene(fxmlLoader.load());
                    Main.mainStage.setScene(scene);
                    Main.mainStage.show();


                }

            }
        }

    }

    public void run_cbx_strumento(ActionEvent actionEvent) {
        String strumento_preferito;
        Boolean esistente = false;
        strumento_preferito = ((String) cbx_strumento.getValue()).toUpperCase();
        for (int i = 0; i < cbx_strumento.getItems().size(); i++) {
            if (strumento_preferito.compareTo((String) cbx_strumento.getItems().get(i)) == 0)
                esistente = true;
        }
        if (!esistente) {
            cbx_strumento.getItems().add(strumento_preferito);
        }
    }

    public void run_cbx_marca(ActionEvent actionEvent) {
        String marca_preferita;
        Boolean esistente = false;
        marca_preferita = ((String) cbx_marca.getValue()).toUpperCase();
        for (int i = 0; i < cbx_marca.getItems().size(); i++) {
            if (marca_preferita.compareTo((String) cbx_marca.getItems().get(i)) == 0)
                esistente = true;
        }
        if (!esistente) {
            cbx_marca.getItems().add(marca_preferita);
        }
    }

    public void run_cbx_tempofumi(ActionEvent actionEvent) {

    }

    public void run_btn_cancella(ActionEvent actionEvent) {
        String[] elenco_strumenti = {"", "SIGARETTA", "SIGARO", "SIGARETTA ELETTRONICA"};
        cbx_strumento.setItems(FXCollections.observableArrayList(elenco_strumenti));
        cbx_strumento.setValue("");
        String[] elenco_marca = {"", "BENSTON", "COHIBA", "WINSTON"};
        cbx_marca.setItems(FXCollections.observableArrayList(elenco_marca));
        cbx_marca.setValue("");
        lbl_stampa.setText("");
    }

    public void run_btn_return(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void onclick_btn_cambiaImmagine1(ActionEvent actionEvent) throws FileNotFoundException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleziona un'immagine");

        File file = fileChooser.showOpenDialog(null);

        if (file != null) {
            String filePath = file.getAbsolutePath();
            Image image = new Image(new FileInputStream(file));
            img_immagineProfilo1.setImage(image);
            for (int i = 0; i< UserList.size() ; i++) {
                User User1 = UserList.get(i);
                if (User1.getUsername().equals(Account_Name)) {
                    User1.setImage_fumatore(filePath);
                }
            }

        }
    }
}

