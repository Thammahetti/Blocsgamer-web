package sample;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.IOException;

public class Controller_Admin_Panel extends Controller {
    public Label lbl_Status_admin;
    public Button btn_login_return;
    public Button btn_remove;
    public RadioButton radio_btn_si;
    public RadioButton radio_btn_np;
    public Button btn_conferma;
    public ComboBox combo_box_admin;
    static boolean confirm_remove = false;
    public void initialize(){
        ToggleGroup toggleGroup = new ToggleGroup();
       radio_btn_si.setToggleGroup(toggleGroup);
       radio_btn_np.setToggleGroup(toggleGroup);
        combo_box_admin.getItems().clear();
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            String username_only_add = User1.getUsername();
            combo_box_admin.getItems().add(username_only_add);
        }


    }
    public void run_btn_login_return(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_login.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void onrun_radio_btn_si(ActionEvent actionEvent) {
        confirm_remove = true;
        btn_conferma.setVisible(true);
    }

    public void run_btn_remove(ActionEvent actionEvent) {
        if (combo_box_admin.getValue().equals("admin")) {
            lbl_Status_admin.setText("NON PUOI ELIMINARE ADMIN");
        }else {
            lbl_Status_admin.setText("Sei Sicuro di eliminare " + combo_box_admin.getValue() + " ?");
            radio_btn_np.setVisible(true);
            radio_btn_si.setVisible(true);
        }
    }

    public void onrun_radio_btn_no(ActionEvent actionEvent) {
        confirm_remove = false;
        btn_conferma.setVisible(true);

    }

    public void run_btn_conferma(ActionEvent actionEvent) {
        if (confirm_remove == false) {
            radio_btn_np.setVisible(false);
            radio_btn_si.setVisible(false);
            lbl_Status_admin.setVisible(false);
            btn_remove.setDisable(true);
            btn_conferma.setVisible(false);
        }
        if (confirm_remove == true) {
            for (int i = 0; i< UserList.size() ; i++) {
                User User1 = UserList.get(i);
                 if (User1.getUsername().equals(combo_box_admin.getValue())) {
                     UserList.remove(i);

                 }
            }

            initialize();
            radio_btn_np.setVisible(false);
            radio_btn_si.setVisible(false);
            lbl_Status_admin.setVisible(false);
            btn_remove.setDisable(true);
            btn_conferma.setVisible(false);
        }

    }

    public void onrun_combo_box_admin(ActionEvent actionEvent) {
        lbl_Status_admin.setVisible(true);
        btn_remove.setDisable(false);
        lbl_Status_admin.setText("SELECTED ACCOUNT  " + combo_box_admin.getValue());


    }
}
