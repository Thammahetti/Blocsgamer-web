package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;

import javax.jws.soap.SOAPBinding;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import static javafx.application.Application.launch;
//Thammahetti Mudalige Thikshana Thejan Peiris
//3FINF
//28/04/2023
//Versione: 1.0.5


public class Controller {
    public Button btn_compilaFormPrincipale;
    public Font x1;
    public Label lbl_Status;
    public Font x2;
    public Button btn_log_out;
    public Button btn_login;
    public PasswordField txt_Password;
    public Button btn_register;
    public Button btn_admin_panel;
    @FXML    TextField txt_Username;
    public String username = "Galvani";
    public String password = "classe3F";
    public static boolean logged = false;

    public static ArrayList<User> UserList = new ArrayList<User>(1);
    public void initialize() throws FileNotFoundException {
        boolean admin_exist = false;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            if (User1.getUsername().equals("admin")) {
                admin_exist = true;
            }

        }
        if (admin_exist == false) {
            User User = new User();
            User.setUsername("admin");
            User.setPassword("admin123");
            User.setImage_Persona("verifica A 3f Thammahetti/src/sample/null_image.png");
            User.setNome("admin");
            User.setCognome("admin123");
            User.setDay(2);
            User.setMonth(3);
            User.setYear(2000);
            UserList.add(User);
        }
        if (logged) {
            btn_compilaFormPrincipale.setDisable(false);
            btn_log_out.setVisible(true);
            lbl_Status.setText("STATUS: Admin LOGGED IN");
            btn_admin_panel.setVisible(true);
        }else {
            btn_compilaFormPrincipale.setDisable(true);
            btn_log_out.setVisible(false);
            btn_admin_panel.setVisible(false);

        }
        txt_Username.setText("admin");
        txt_Password.setText("admin123");
    }

    public void onclick_btn_compilaFormPrincipale(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void run_btn_login(ActionEvent actionEvent) {
        String user_input = txt_Username.getText();
        String user_pass = txt_Password.getText();
        int pos_user = 0;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);

            if (User1.getUsername().equals(user_input)) {
                pos_user = i;
            }

        }
        User User1 = UserList.get(pos_user);

             if ((User1.getUsername().equals(user_input) && User1.getPassword().equals(user_pass))) {
                 if (user_input.equals("admin") && user_pass.equals("admin123")) {
                     btn_admin_panel.setVisible(true);
                 }else {
                     btn_admin_panel.setVisible(false);
                 }

                 btn_compilaFormPrincipale.setDisable(false);
                 lbl_Status.setText("STATUS: " + user_input + " LOGGED IN");
                 btn_log_out.setVisible(true);
                 ControllerFormPersona.Account_Name = User1.getUsername();
                 logged = true;

             } else {
                 btn_admin_panel.setVisible(false);
                 btn_log_out.setVisible(false);
                 btn_compilaFormPrincipale.setDisable(true);
                 lbl_Status.setText(String.valueOf(pos_user));

             }

/*
User user = (User) obj;
            if(user_input.equals(user.Username) &&  user_pass.equals(user.Password)) {

                btn_compilaFormPrincipale.setDisable(false);
                lbl_Status.setText("STATUS: " + user_input + " LOGGED IN");
                btn_log_out.setVisible(true);
                logged = true;

            }else {
                btn_log_out.setVisible(false);
                btn_compilaFormPrincipale.setDisable(true);
                lbl_Status.setText(String.valueOf(i));
            }



            if (user_input.equals(username) && user_pass.equals(password)) {
                btn_compilaFormPrincipale.setDisable(false);
                lbl_Status.setText("STATUS: Galvani LOGGED IN");
                btn_log_out.setVisible(true);
                logged = true;
            } else {
                btn_log_out.setVisible(false);
                btn_compilaFormPrincipale.setDisable(true);
                lbl_Status.setText("STATUS: NOT LOGGED");
            }

 */
        }


    public void run_btn_log_out(ActionEvent actionEvent) {
        txt_Username.setText("");
        txt_Password.setText("");
        btn_log_out.setVisible(false);
        lbl_Status.setText("STATUS:");
        btn_compilaFormPrincipale.setDisable(true);
    }

    public void run_btn_register(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_register.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void run_btn_admin_panel(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_admin_panel.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }
}
