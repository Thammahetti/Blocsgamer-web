package sample;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;

//Brignoli Tommaso 3F Inf 18/04/23 versione 1.0.3 beta


public class controllersportivo extends ControllerFormPersona{


    public Label lbl_datinseriti;
    public TextField txt_Sport;
    public TextField txt_anni;
    public TextField txt_nomeUtente;
    public TextField txt_cognomeUtente;
    public Button Btn_Conferma_Dati;
    public Button Btn_Cancella_Dati;
    public ComboBox cmbx_sport_predicate;
    protected String data_nascita_utente;
    public String duratasport;
    public Label lbl_errore_anni;
    public ComboBox cmbx_Mesi_Sport;
    public static Boolean Sportivo_com = false;

    public void oncliclìk_Btn_Conferma_Dati(ActionEvent actionEvent) throws IOException {
        Sportivo_com = false;
        for (int i = 0; i< UserList.size() ; i++) {
            User User1 = UserList.get(i);
            if (User1.getUsername().equals(Account_Name)) {

                User1.setSport_prat((String) cmbx_sport_predicate.getValue());
                User1.setMesi_prat((String) cmbx_Mesi_Sport.getValue());

                Scene scene;
                Sportivo_com = true;
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
                scene = new Scene(fxmlLoader.load());
                Main.mainStage.setScene(scene);
                Main.mainStage.show();


            }

        }

    }


    public void onclick_Btn_Cancella_Dati(ActionEvent actionEvent) {
        lbl_datinseriti.setText("DATI INSERITI:");
        cmbx_Mesi_Sport.setValue("");
        cmbx_sport_predicate.getItems().clear();
        String[] elenco_sport = {"", "CALCIO", "BASKET", "GOLF"};
        cmbx_sport_predicate.setItems(FXCollections.observableArrayList(elenco_sport));
    }
    public void initialize() {
        String[] elenco_sport = {"", "CALCIO", "BASKET", "GOLF"};
        cmbx_sport_predicate.setItems(FXCollections.observableArrayList(elenco_sport));
    }
    public void onclick_cmbx_sport_praticato(ActionEvent actionEvent) {
        String sport_praticato;
        boolean esistente = false;
        //ConfigEvent cmbx_sport_predicato;
        sport_praticato=((String) cmbx_sport_predicate.getValue()).toUpperCase();
        for (int i= 0;i<cmbx_sport_predicate.getItems().size();i++) {
            if (sport_praticato.compareTo((String) cmbx_sport_predicate.getItems().get(i))==0)
                esistente = true;
        }
        if (!esistente) {
            cmbx_sport_predicate.getItems().add(sport_praticato);
        }


    }
}
