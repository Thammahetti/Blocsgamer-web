package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.time.LocalDate;

public class Controller_Sportivo extends ControllerFormPersona {
    public Label lbl_note1;
    public Label lbl_nomeUtente1;
    public TextField txt_anni;
    public Button btn_confermaDati;
    public Label lbl_note;
    public Label lbl_nomeUtente;
    public TextField txt_sport;
    public Button btn_back;

    public void Controller_Register(String name, String surname, String data_nascita_utente) {
        this.name = name;
        this.surname = surname;
        this.data_nascita_utente = data_nascita_utente;
    }
    public void onclick_btn_confermaDati(ActionEvent actionEvent) {

        String sport = txt_sport.getText();
        String AnniGiocati = txt_anni.getText();
        int Anni = Integer.parseInt(AnniGiocati);
        LocalDate AnnoPraticato = LocalDate.now().minusYears(Anni);
        int yanno = AnnoPraticato.getYear();
        String note = "";
        String note1;
        note1 = "Sport: " + sport + "E giochi da " + AnniGiocati;

        note = "NOTE: Name: " + name + " Surname: " + surname + " Date: " + data_nascita_utente ;
        if (y> yanno) {
            txt_anni.setStyle("-fx-background-color: red;");
        }else {
            txt_anni.setStyle("-fx-background-color: white;");
            lbl_note.setText(note);
            lbl_note1.setText(note1);
        }





    }

    public void onclick_btn_back(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void onclick_btn_reset_sport(ActionEvent actionEvent) {
        txt_anni.setText("");
        txt_sport.setText("");
        lbl_note.setText("");
        lbl_note1.setText("");
    }
}
