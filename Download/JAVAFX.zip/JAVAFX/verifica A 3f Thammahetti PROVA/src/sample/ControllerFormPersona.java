package sample;
import java.io.FileInputStream;
import java.time.LocalDate;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.IOException;
//Thammahetti Mudalige Thikshana Thejan Peiris
//3FINF
//04/04/2023
//Versione: 1.0.2 beta
public class ControllerFormPersona extends Controller {

    //public  DatePicker datepicker_data;
    public DatePicker dtpick_dataUtente;
    public Button btn_confermaDati;
    public Button btn_cambiaImmagine;
    public TextField txt_cognomeUtente;
    public Label lbl_nomeUtente1;
    public Label lbl_nomeUtente11;
    public DatePicker data_picker;
    public Button btn_reset;
    public Button btn_sportivo;
    public Button btn_back;
    protected  LocalDate data_inserita;
    protected int giorno;
    protected int mese;
    protected int anno;
    public static String data_nascita_utente;
    public TextField txt_nomeUtente;
    public Label lbl_nomeUtente;
    public Label lbl_note;
    public ImageView img_immagineProfilo;
    public LocalDate data_input;
    int d;
    int m;
    public static int y;
    public static String name;
    public static String surname;
    public void onclick_btn_Login(ActionEvent actionEvent) {

    }

    public void onclick_btn_confermaDati(ActionEvent actionEvent) {
        name = txt_nomeUtente.getText();
        surname = txt_cognomeUtente.getText();
        String note ;


        LocalDate birthDate = data_picker.getValue();
        LocalDate legalAgeDate = LocalDate.now().minusYears(18);


        if (birthDate.isAfter(legalAgeDate)) {
            note = "NOTE: Name: " + name + " Surname: " + surname + " Date: " + data_nascita_utente + "E sei minorenne";
        } else {
            note = "NOTE: Name: " + name + " Surname: " + surname + " Date: " + data_nascita_utente + "E sei maggiorenne";
        }

        lbl_note.setText(note);
        btn_sportivo.setDisable(false);
    }

    public void onclick_btn_cambiaImmagine(ActionEvent actionEvent)throws IOException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleziona un'immagine");

        File file = fileChooser.showOpenDialog(null);

        if (file != null) {

            Image image = new Image(new FileInputStream(file));
            img_immagineProfilo.setImage(image);

        }
    }


    public void run_data_picker(ActionEvent actionEvent) {

        data_input = data_picker.getValue();
        d =data_input.getDayOfMonth();
        m = data_input.getMonthValue();
        y = data_input.getYear();
        data_nascita_utente = Integer.toString(d) + "/" + Integer.toString(m) + "/" + Integer.toString(y);
    }

    public void onclick_btn_reset(ActionEvent actionEvent) {
        txt_nomeUtente.setText("");
        txt_cognomeUtente.setText("");
        data_picker.setValue(null);
        lbl_note.setText("");


    }

    public void onclick_btn_back(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_login.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();

    }

    public void onclick_btn_sportivo(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_sportivo.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }
}
