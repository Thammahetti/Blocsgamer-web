package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;
    //Thammahetti Muda lige Thikshana Thejan Peiris
    //3FINF
    //04/04/2023
    //Versione: 1.0.2 beta
public class Main extends Application {
    protected static boolean logged = true;
    public static Stage mainStage;

    @Override
    public void start(Stage primaryStage) throws IOException {
        mainStage = primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("form_login.fxml"));
        mainStage.setTitle("Verifica 3F : Thammahetti Thejan 04/04/2023 1.0.2 beta");

        mainStage.setScene(new Scene(root));
        mainStage.show();
}
    public static void main(String[] args) throws IOException {
        launch(args);
    }
}
