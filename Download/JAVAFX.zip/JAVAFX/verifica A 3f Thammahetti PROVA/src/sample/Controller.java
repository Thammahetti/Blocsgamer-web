package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;

import java.io.IOException;

import static javafx.application.Application.launch;
//Thammahetti Mudalige Thikshana Thejan Peiris
//3FINF
//04/04/2023
//Versione: 1.0.2 beta

public class Controller {
    public Button btn_compilaFormPrincipale;
    public Font x1;
    public Label lbl_Status;
    public Font x2;
    public Button btn_log_out;
    public Button btn_login;
    public PasswordField txt_Password;
    @FXML    TextField txt_Username;
    public String username = "Galvani";
    public String password = "classe3F";

    public void onclick_btn_compilaFormPrincipale(ActionEvent actionEvent) throws IOException {
        Scene scene;
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("form_Persona.fxml"));
        scene = new Scene(fxmlLoader.load());
        Main.mainStage.setScene(scene);
        Main.mainStage.show();
    }

    public void run_btn_login(ActionEvent actionEvent) {
        String user_input = txt_Username.getText();
        String user_pass = txt_Password.getText();


            if (user_input.equals(username) && user_pass.equals(password)) {
                btn_compilaFormPrincipale.setDisable(false);
                lbl_Status.setText("STATUS: Galvani LOGGED IN");
                btn_log_out.setVisible(true);
            } else {
                btn_log_out.setVisible(false);
                btn_compilaFormPrincipale.setDisable(true);
                lbl_Status.setText("STATUS: NOT LOGGED");
            }
        }


    public void run_btn_log_out(ActionEvent actionEvent) {
        txt_Username.setText("");
        txt_Password.setText("");
        btn_log_out.setVisible(false);
        lbl_Status.setText("STATUS:");
        btn_compilaFormPrincipale.setDisable(true);
    }

}
